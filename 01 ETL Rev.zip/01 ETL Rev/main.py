from sqlalchemy import create_engine, MetaData
from sqlalchemy import (Table, Column, String, Integer)

# Import pandas as pd
import pandas as pd
import sqlite3

# Assign the filename: file
file = 'bank-full_pa.csv'

#print a csv file
file = open('bank-full_pa.csv', mode='r')

# Read the file into a DataFrame: df
inputdf = pd.read_csv(file)

# View the head of the DataFrame
print(inputdf.head())
print(inputdf)


# Print it
#print(file.read())

# Establish a connection to sqlite
#print(file.closed)
engine = create_engine('sqlite:///rev.sqlite')
metadata = MetaData()
table1 = Table('table1', metadata,
               Column('age', Integer()),
               Column('job', String()),
               Column('marital', String()),
               Column('education', String()),
               Column('default', String()),
               Column('balance', String()),
               Column('housing', String()),
               Column('loan', String()),
               Column('day', String()),
               Column('month', String()),
               Column('duration', String()),
               Column('campaign', String()),
               Column('pdays', String()),
               Column('previous', String()),
               Column('poutcome', String()),
               Column('success', String()) )

               
metadata.create_all(engine)

pd.set_option('display.max_columns', None)  # or 1000
pd.set_option('display.max_rows', None)  # or 1000
pd.set_option('display.max_colwidth', -1)  # or 199
#Load section
con = sqlite3.connect("rev.sqlite")
outputdf = inputdf.to_sql("table1", con, if_exists="replace")
print(outputdf)
#outputdf = #pd.read_sql_query("SELECT * from table1", con)
#print(outputdf)
#outputdf = pd.read_sql_query("SELECT age,job from table1", con)
#print(outputdf)
#outputdf = pd.read_sql_query("SELECT * from table1 where success = 'no'", con)
#print(outputdf)
outputdf = pd.read_sql_query("SELECT * from table1  LIMIT 20", con)
print(outputdf)
outputdf = pd.read_sql_query("SELECT count(*) AS ANSB from table1", con)
print(outputdf)
outputdf = pd.read_sql_query("SELECT count(*) AS ANSC from table1 where success='yes'", con)
print(outputdf)
outputdf = pd.read_sql_query("SELECT count(*) AS ANSD from table1 where age BETWEEN 40 AND 54 ", con)
print(outputdf)


cursor = con.cursor()

sql_update_query = """Update table1 set success = 'no' WHERE success is null"""
cursor.execute(sql_update_query)
con.commit()
print("Record Updated successfully ")
cursor.close()


con.close()